import { Component } from '@angular/core';

@Component({
  selector: 'app-pnf',
  templateUrl: './pnf.component.html',
  styleUrl: './pnf.component.css'
})
export class PnfComponent {

}
