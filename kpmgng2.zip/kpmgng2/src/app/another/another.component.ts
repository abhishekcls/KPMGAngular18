import { Component } from '@angular/core';

@Component({
  selector: 'app-another',
  templateUrl: './another.component.html',
  styleUrl: './another.component.css'
})
export class AnotherComponent {

}
