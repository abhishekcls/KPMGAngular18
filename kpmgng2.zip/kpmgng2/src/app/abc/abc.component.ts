import { Component } from '@angular/core';

@Component({
  selector: 'kpmg-abc',
  templateUrl: './abc.component.html',
  styleUrl: './abc.component.css'
})
export class AbcComponent {

}
