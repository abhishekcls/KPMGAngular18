import { Component } from '@angular/core';

@Component({
  selector: 'app-nested',
  templateUrl: './nested.component.html',
  styleUrl: './nested.component.css'
})
export class NestedComponent {
  path:string="https://gifdb.com/images/high/smiley-face-laughing-emoji-ce241mv38xv5n1gk.gif"
  basepath:string="https://gifdb.com/images/high/";

  flag:boolean=false;

  disp(){
    alert('Hello')
  }
}
