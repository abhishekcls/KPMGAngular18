let fruits=['Apple','Banana','Kiwi'];
/*
console.log(fruits,typeof fruits)

for(let i in fruits){
    console.log(i,fruits[i])
}

fruits.forEach(function(v,i){
    console.log(i,v);
});
*/
fruits.forEach(v=>console.log(v));
/*
for(let f of fruits){
    console.log(f);
}*/