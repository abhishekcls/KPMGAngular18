let emp={
    "eid":101,
    "ename":"Ravi",
    "city":"BLR"
}
//let {eid,...e}=emp;//object destructure
//console.log(eid,e)

let {eid,city}=emp;//object destructure
console.log(eid,city)

let fruits=['Apple','Banana','Kiwi'];
let [a,...rem]=fruits//array destructure

console.log(a,rem);

let fcopy=[...fruits];
fcopy.push('Mango')
console.log(fcopy,fruits)