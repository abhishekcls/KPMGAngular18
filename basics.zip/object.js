let emp={
    "eid":101,
    "ename":"Ravi",
    "details":function(){
        console.log(this.eid,this.ename)
    }
}

emp2=emp;

console.log(emp, typeof(emp))
emp.details()
emp.ename="Prateek";

console.log(emp2, typeof(emp2))
emp2.details()

console.log(Array.isArray(emp));

let fruits=['Apple','Banana','Kiwi'];
console.log(Array.isArray(fruits));

for(e in emp){
    console.log(e);
}