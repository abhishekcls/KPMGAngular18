function fx1(){
    console.log("Hello")
}

fx1()

fx2=function(){
    console.log("Hi")
}

fx2();
console.log(typeof fx2);

(function(){
    console.log("Hey")
})()