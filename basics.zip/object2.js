let emp={
    "eid#":101,
    "ename":"Ravi"
}

//console.log(emp.eid,emp.ename)//not recommened
console.log(emp["eid#"],emp["ename"])//recommended

for(e in emp){
    console.log(e,emp[e])
}