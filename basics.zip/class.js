class Demo
{
    constructor(){
        this.a=10;
        console.log("P Cons");
    }
    disp(){
        console.log("Hello")
    }
}

let d=new Demo();//object
d.disp();
console.log(d,typeof d)

class Child extends Demo{
    constructor(){
        super();
        console.log("C Cons");
    }
}

let c=new Child();
c.disp();