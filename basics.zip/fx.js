const a=100;//global
function abc(){
    const a=20;
    console.log(a);
    if(true){
        //console.log(a);error
        const a=10;
        console.log(a);
    }
    console.log(a);
}

abc();
console.log(a,typeof a);