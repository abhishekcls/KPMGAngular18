add=function(a,b,c=0){
    console.log(`c=${c}`);
    console.log(a+b+c);
}

add(1,4);
add(1,3,4);