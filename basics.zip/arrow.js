// function add(a,b){
//     console.log(a+b);
// }
add=(a,b)=>console.log(a+b);

add(10,20)

square=a=>a*a;

let sqr=square(5);
console.log(sqr);