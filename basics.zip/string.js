let str1="Abhishek";
let str2='Abhishek \' " ';
let str3=`Abhishek ' "`;

console.log(str1,typeof(str1));
console.log(str2,typeof(str2));
console.log(str3,typeof(str3));

console.log("Hello "+str1);
console.log(`Hello ${str1}`);