console.log(a);//hoisting

var a=10;
console.log(a, typeof(a));

a="abc";
console.log(a, typeof(a));