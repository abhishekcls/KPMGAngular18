import { Component } from '@angular/core';
import { RESTApiService } from '../restapi.service';

@Component({
  selector: 'app-callapi',
  templateUrl: './callapi.component.html',
  styleUrl: './callapi.component.css'
  
})
export class CallapiComponent {
  users:any;
  constructor(rapi:RESTApiService){//DI
    rapi.getUsers().subscribe(u=>{this.users=u; console.log(this.users)});
  }
  ngOnInit(){
    //this.rapi
  }
}
