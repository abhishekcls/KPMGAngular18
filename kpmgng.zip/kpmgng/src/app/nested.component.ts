import { Component, Input } from "@angular/core";

@Component({
    selector:'nested',
    template:`<h2>Nested Component</h2>
    <div [ngClass]="{'high':emp.sal>=70000,'low':emp.sal<50000}">{{emp | json}}</div>
    <div>{{emp.sal}}</div>
    {{emp.retired}}
    <img *ngIf="emp.retired" src="https://gifdb.com/images/high/smiley-face-laughing-emoji-ce241mv38xv5n1gk.gif" height="100" width="100"/>
    <img *ngIf="!emp.retired" src="https://media0.giphy.com/media/Pn1h5Un3LZD9uq3u07/200w.gif" height="100" width="100"/>
    `,
    styles:[`
        .high{
            color:red
        }
        .low{
            color:green
        }
        `]
})
export class NestedComponent{
    @Input() emp:any;
}