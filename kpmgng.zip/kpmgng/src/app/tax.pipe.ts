import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'tax'
})
export class TaxPipe implements PipeTransform{
    transform(s:number,r:number=0.1):number {
        return s*r;
    }
}