import { Component } from "@angular/core";

@Component({
    selector:'kpmgapp',
    templateUrl:`app.component.html`,
    styleUrl:`app.component.css`,
    //standalone:true
})
export class AppComponent{
    name:string='Abhishek';
    fruits:string[]=['Apple','Orange','Banana'];
    emp={"eid":101,"ename":"Tarun"};
    emps=[
        {"eid":1001,"ename":"Ravi","gender":"M","sal":45000,"retired":false,"doj":new Date("2001:01-05")},
        {"eid":1002,"ename":"Priya","gender":"F","sal":55000,"retired":false,"doj":new Date("2011:09-07")},
        {"eid":1003,"ename":"Anju","gender":"F","sal":95000,"retired":true,"doj":new Date("1991:11-02")},
        {"eid":1004,"ename":"Jatin","gender":"M","sal":67000,"retired":false,"doj":new Date("2015:08-02")},
        {"eid":1005,"ename":"Prakash","gender":"M","sal":87000,"retired":true,"doj":new Date("1982:04-01")},
    ]
    constructor(){
        this.name='Abhishek Samanta';
    }
   //single line comment
}