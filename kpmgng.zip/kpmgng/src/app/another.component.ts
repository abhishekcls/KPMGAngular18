import { Component } from "@angular/core";

@Component({
    selector:'another',
    template:'<h1>Another Component</h1>'
})
export class AnotherComponent{}